const assert=require('node:assert/strict');const fs=require('node:fs');const path=require('node:path');
const State=require('./reward-core.js');const items=JSON.parse(fs.readFileSync(path.join(__dirname,'items.json')));let count=0;
function test(name,fn){fn();count++;console.log('PASS',name);}
const state=()=>new State(items.map(x=>x.id));
test('all six item mappings exist',()=>{for(const i of items){assert(fs.existsSync(path.join(__dirname,i.model)));assert(fs.existsSync(path.join(__dirname,i.icon)));}assert.equal(new Set(items.map(i=>i.id)).size,6);});
test('duplicate drop cannot grant twice',()=>{let s=state(),d={id:'a',item:'currency.coin',quantity:2};assert(s.claim(d).ok);assert(!s.claim(d).ok);assert.equal(s.inventory[d.item],2);});
test('different drops accumulate',()=>{let s=state();for(const id of ['a','b'])assert(s.claim({id,item:'currency.coin',quantity:2}).ok);assert.equal(s.inventory['currency.coin'],4);});
test('invalid drops preserve state',()=>{let s=state();for(const quantity of [-1,0,1.5,NaN,Infinity])assert(!s.claim({id:'a',item:'currency.coin',quantity}).ok);assert(!s.claim({id:'b',item:'unknown',quantity:1}).ok);assert.equal(s.claimed.size,0);});
test('empty potion does not heal',()=>{let s=state();assert(!s.heal().ok);assert.equal(s.hp,40);});
test('potion consumed and healing clamped',()=>{let s=state();s.inventory['consumable.health_potion']=2;s.hp=90;assert(s.heal().ok);assert.equal(s.hp,100);assert.equal(s.inventory['consumable.health_potion'],1);assert(!s.heal().ok);assert.equal(s.inventory['consumable.health_potion'],1);});
test('one chest gives coins only once',()=>{let s=state();s.inventory['reward.chest']=1;assert(s.openChest().ok);assert(!s.openChest().ok);assert.equal(s.inventory['currency.coin'],10);});
test('overflow chest does not consume',()=>{let s=state();s.inventory['reward.chest']=1;s.inventory['currency.coin']=Number.MAX_SAFE_INTEGER;assert(!s.openChest().ok);assert.equal(s.inventory['reward.chest'],1);});
test('reset clears demo session',()=>{let s=state();s.claim({id:'a',item:'currency.coin',quantity:1});s.reset();assert.equal(s.claimed.size,0);assert.equal(s.inventory['currency.coin'],0);assert.equal(s.hp,40);});
fs.writeFileSync(path.join(__dirname,'reward-validation.json'),JSON.stringify({status:'PASS',tests:count,scope:'Node state logic and local asset paths, not browser automation'},null,2));
