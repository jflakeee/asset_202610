# Trailwood 신규 96종 확장 제작안

작성: 2026-10-23 · **제안 단계 / 미구현 / 아트 승인 대기**

외부 메시·텍스처를 복사/변형하지 않고 자체 좌표·seed·팔레트로 제작. 무료팩은 품목 구성/연결 방식 조사 자료이며 형상 원본으로 사용하지 않음.

기존 104종과 합쳐 고유 모델 200종을 목표로 한다. 테마와 LOD는 고유 모델 수를 늘리지 않는다. 새 접두사 CAVE/RUIN/CAMP/FARM을 사용하며 기존 숲·바위·경계 모델을 재명명해 신규로 세지 않는다.

## 제작 순서

1. 동굴 연결 규격: 직선·곡선·T자·경사 각 1개로 통행/연결 시제품 검증 후 24종 제작.
2. 유적 모듈: 벽·아치·문·계단 4종으로 공간을 완성한 뒤 파손 부재 확장.
3. 야영지: 텐트·모닥불·취사 삼각대·냄비를 함께 배치해 크기와 상호 간섭 검토.
4. 농장: 밀 4단계를 먼저 검증하고 뿌리 pivot·심기 셀을 고정한 뒤 나머지 작물 확장.

## 동굴·암벽 — 24종

| ID | 모델 | 목표 크기 X×Y×Z(m) | 제작 프로파일 |
|---|---|---|---|
| `TW_CAVE_ENTRANCE_ARCH_A` | 동굴 아치 입구 | 3×3×1 | arch |
| `TW_CAVE_ENTRANCE_LOW_A` | 낮은 동굴 입구 | 3×2×1 | arch |
| `TW_CAVE_TUNNEL_STRAIGHT_A` | 직선 통로 | 3×3×2 | tunnel |
| `TW_CAVE_TUNNEL_CURVE_L_A` | 왼쪽 굽은 통로 | 3×3×3 | tunnel |
| `TW_CAVE_TUNNEL_CURVE_R_A` | 오른쪽 굽은 통로 | 3×3×3 | tunnel |
| `TW_CAVE_TUNNEL_T_A` | T자 교차 통로 | 5×3×3 | tunnel |
| `TW_CAVE_TUNNEL_CROSS_A` | 십자 교차 통로 | 5×3×5 | tunnel |
| `TW_CAVE_TUNNEL_END_A` | 막힌 통로 | 3×3×2 | tunnel |
| `TW_CAVE_TUNNEL_RAMP_A` | 완만한 경사 통로 | 3×3×4 | tunnel |
| `TW_CAVE_FLOOR_FLAT_A` | 평평한 동굴 바닥 | 2×0.2×2 | surface |
| `TW_CAVE_FLOOR_ROUGH_A` | 거친 동굴 바닥 | 2×0.3×2 | surface |
| `TW_CAVE_FLOOR_POOL_RIM_A` | 웅덩이 둘레 바닥 | 2×0.3×2 | surface |
| `TW_CAVE_WALL_STRAIGHT_A` | 동굴 직선 벽 | 2×3×0.8 | wall |
| `TW_CAVE_WALL_CONCAVE_A` | 오목한 동굴 벽 | 2×3×2 | wall |
| `TW_CAVE_WALL_CONVEX_A` | 볼록한 동굴 벽 | 2×3×2 | wall |
| `TW_CAVE_WALL_LEDGE_A` | 돌출 선반 암벽 | 2×3×1.2 | wall |
| `TW_CAVE_CEILING_FLAT_A` | 평평한 천장 | 2×0.4×2 | ceiling |
| `TW_CAVE_CEILING_VAULT_A` | 둥근 천장 | 2×1×2 | ceiling |
| `TW_CAVE_STALACTITE_SINGLE_A` | 종유석 단일 | 0.5×1.2×0.5 | hanging |
| `TW_CAVE_STALACTITE_CLUSTER_A` | 종유석 무리 | 1.2×1.5×1.2 | hanging |
| `TW_CAVE_STALAGMITE_SINGLE_A` | 석순 단일 | 0.5×1.1×0.5 | prop |
| `TW_CAVE_STALAGMITE_CLUSTER_A` | 석순 무리 | 1.2×1.4×1.2 | prop |
| `TW_CAVE_CRYSTAL_CLUSTER_A` | 광물 결정 무리 | 0.8×0.9×0.7 | prop |
| `TW_CAVE_ORE_VEIN_A` | 암벽 광맥 | 1×0.5×0.2 | wall_prop |

## 유적·던전 — 24종

| ID | 모델 | 목표 크기 X×Y×Z(m) | 제작 프로파일 |
|---|---|---|---|
| `TW_RUIN_FLOOR_TILE_A` | 유적 바닥 타일 | 2×0.2×2 | surface |
| `TW_RUIN_FLOOR_BROKEN_A` | 깨진 유적 바닥 | 2×0.25×2 | surface |
| `TW_RUIN_WALL_SOLID_A` | 유적 벽체 | 2×3×0.4 | wall |
| `TW_RUIN_WALL_WINDOW_A` | 창이 있는 유적 벽 | 2×3×0.4 | wall |
| `TW_RUIN_WALL_COLLAPSED_A` | 붕괴된 유적 벽 | 2×1.8×0.8 | wall |
| `TW_RUIN_WALL_CORNER_L_A` | 유적 왼쪽 모서리 | 2×3×2 | wall |
| `TW_RUIN_WALL_CORNER_R_A` | 유적 오른쪽 모서리 | 2×3×2 | wall |
| `TW_RUIN_ARCH_DOOR_A` | 아치형 출입구 | 2×3×0.6 | arch |
| `TW_RUIN_ARCH_BROKEN_A` | 파손 아치 | 2×3×0.8 | arch |
| `TW_RUIN_DOOR_SLAB_A` | 돌문 판 | 1.5×2.4×0.2 | door |
| `TW_RUIN_PILLAR_ROUND_A` | 원형 기둥 | 0.6×3×0.6 | prop |
| `TW_RUIN_PILLAR_SQUARE_A` | 각진 기둥 | 0.7×3×0.7 | prop |
| `TW_RUIN_PILLAR_BROKEN_A` | 부러진 기둥 | 0.8×1.3×0.8 | prop |
| `TW_RUIN_PILLAR_FALLEN_A` | 쓰러진 기둥 | 2.5×0.7×0.8 | prop |
| `TW_RUIN_CAPITAL_A` | 기둥 머리 | 1×0.4×1 | prop |
| `TW_RUIN_PEDESTAL_A` | 석조 받침대 | 1×0.8×1 | prop |
| `TW_RUIN_ALTAR_A` | 제단 | 1.8×1×1 | prop |
| `TW_RUIN_MONOLITH_A` | 기하학 문양 비석 | 0.8×2×0.5 | prop |
| `TW_RUIN_STAIRS_ASCENT_A` | 층고 연결 계단 | 2×1×3 | surface |
| `TW_RUIN_STAIRS_BROKEN_A` | 파손 계단 | 2×1×3 | surface |
| `TW_RUIN_LANDING_A` | 계단참 | 2×0.2×2 | surface |
| `TW_RUIN_BRAZIER_A` | 석조 화로 | 0.7×1×0.7 | prop |
| `TW_RUIN_RUBBLE_BRICKS_A` | 벽돌 잔해 더미 | 1.5×0.4×1 | prop |
| `TW_RUIN_RUBBLE_ARCH_A` | 아치 잔해 더미 | 1.6×0.6×1.2 | prop |

## 야영·생존 — 24종

| ID | 모델 | 목표 크기 X×Y×Z(m) | 제작 프로파일 |
|---|---|---|---|
| `TW_CAMP_TENT_RIDGE_A` | 능선형 텐트 | 2.4×1.8×3 | tent |
| `TW_CAMP_TENT_LEANTO_A` | 한쪽 경사 쉼터 | 2.4×2×2 | tent |
| `TW_CAMP_TENT_DOME_A` | 돔형 텐트 | 2.5×1.6×2.5 | tent |
| `TW_CAMP_TARP_CANOPY_A` | 방수포 차양 | 3×2.3×3 | tent |
| `TW_CAMP_BEDROLL_ROLLED_A` | 말린 침낭 | 0.7×0.35×0.4 | prop |
| `TW_CAMP_BEDROLL_OPEN_A` | 펼친 침낭 | 0.8×0.12×2 | prop |
| `TW_CAMP_BACKPACK_A` | 배낭 | 0.45×0.65×0.3 | prop |
| `TW_CAMP_SACK_TIED_A` | 묶은 보급 자루 | 0.5×0.65×0.5 | prop |
| `TW_CAMP_FIRE_RING_A` | 모닥불 돌테 | 1×0.2×1 | prop |
| `TW_CAMP_FIREWOOD_BUNDLE_A` | 묶은 장작 | 0.7×0.35×0.5 | prop |
| `TW_CAMP_COOKING_TRIPOD_A` | 취사용 삼각대 | 1×1.5×1 | prop |
| `TW_CAMP_COOKING_POT_A` | 취사용 냄비 | 0.5×0.4×0.5 | prop |
| `TW_CAMP_KETTLE_A` | 주전자 | 0.35×0.3×0.25 | prop |
| `TW_CAMP_SKILLET_A` | 프라이팬 | 0.6×0.08×0.3 | prop |
| `TW_CAMP_MUG_A` | 캠핑 컵 | 0.13×0.12×0.1 | prop |
| `TW_CAMP_BOWL_A` | 식기 그릇 | 0.2×0.08×0.2 | prop |
| `TW_CAMP_CANTEEN_A` | 휴대 물통 | 0.2×0.3×0.1 | prop |
| `TW_CAMP_WATER_BARREL_A` | 수도꼭지 달린 물통 | 0.6×0.9×0.6 | prop |
| `TW_CAMP_LANTERN_A` | 휴대 랜턴 | 0.2×0.4×0.2 | prop |
| `TW_CAMP_TORCH_STAND_A` | 횃불 거치대 | 0.4×1.5×0.4 | prop |
| `TW_CAMP_HATCHET_A` | 손도끼 | 0.4×0.65×0.08 | tool |
| `TW_CAMP_PICKAXE_A` | 곡괭이 | 0.7×1×0.08 | tool |
| `TW_CAMP_SHOVEL_A` | 삽 | 0.25×1.1×0.08 | tool |
| `TW_CAMP_DRYING_RACK_A` | 식재료 건조대 | 1.4×1.6×0.8 | prop |

## 농장·채집 — 24종

| ID | 모델 | 목표 크기 X×Y×Z(m) | 제작 프로파일 |
|---|---|---|---|
| `TW_FARM_WHEAT_SPROUT_A` | 밀 새싹 | 1×1.8×1 이내 | crop |
| `TW_FARM_WHEAT_YOUNG_A` | 밀 성장기 | 1×1.8×1 이내 | crop |
| `TW_FARM_WHEAT_MATURE_A` | 밀 성숙기 | 1×1.8×1 이내 | crop |
| `TW_FARM_WHEAT_HARVESTABLE_A` | 밀 수확기 | 1×1.8×1 이내 | crop |
| `TW_FARM_CARROT_SPROUT_A` | 당근 새싹 | 1×1.8×1 이내 | crop |
| `TW_FARM_CARROT_YOUNG_A` | 당근 성장기 | 1×1.8×1 이내 | crop |
| `TW_FARM_CARROT_MATURE_A` | 당근 성숙기 | 1×1.8×1 이내 | crop |
| `TW_FARM_CARROT_HARVESTABLE_A` | 당근 수확기 | 1×1.8×1 이내 | crop |
| `TW_FARM_PUMPKIN_SPROUT_A` | 호박 새싹 | 1×1.8×1 이내 | crop |
| `TW_FARM_PUMPKIN_YOUNG_A` | 호박 성장기 | 1×1.8×1 이내 | crop |
| `TW_FARM_PUMPKIN_MATURE_A` | 호박 성숙기 | 1×1.8×1 이내 | crop |
| `TW_FARM_PUMPKIN_HARVESTABLE_A` | 호박 수확기 | 1×1.8×1 이내 | crop |
| `TW_FARM_CORN_SPROUT_A` | 옥수수 새싹 | 1×1.8×1 이내 | crop |
| `TW_FARM_CORN_YOUNG_A` | 옥수수 성장기 | 1×1.8×1 이내 | crop |
| `TW_FARM_CORN_MATURE_A` | 옥수수 성숙기 | 1×1.8×1 이내 | crop |
| `TW_FARM_CORN_HARVESTABLE_A` | 옥수수 수확기 | 1×1.8×1 이내 | crop |
| `TW_FARM_SOIL_BED_A` | 경작지 단위 | 2×0.15×2 | surface |
| `TW_FARM_FURROW_END_A` | 밭고랑 끝단 | 2×0.15×0.5 | surface |
| `TW_FARM_IRRIGATION_CHANNEL_A` | 관개 수로 | 0.4×0.2×2 | surface |
| `TW_FARM_SCARECROW_A` | 허수아비 | 1×1.8×0.4 | prop |
| `TW_FARM_HARVEST_BASKET_A` | 수확 바구니 | 0.6×0.4×0.4 | prop |
| `TW_FARM_WATERING_CAN_A` | 물뿌리개 | 0.55×0.4×0.25 | prop |
| `TW_FARM_SEED_TRAY_A` | 파종 트레이 | 0.6×0.1×0.4 | prop |
| `TW_FARM_GRAIN_BIN_A` | 곡물 저장통 | 0.8×1.1×0.8 | prop |

## 제작·검증 규칙

치수는 glTF Y-up 기준이며 X는 폭, Y는 높이, Z는 깊이이다. 아래 수치는 모두 제작 목표로 실제 측정 결과가 아니다.

- **arch**: 좌우 기둥과 자체 좌표의 아치 단면을 분리 압출해 조합; 연결: 입구/출구 중심 2개, 바닥 기준 Y=0; 통행 폭 최소 1.5m; 충돌: 기둥·상부 분리 convex; 출입구를 막는 전체 convex 금지; LOD0 목표 ≤900 triangles.
- **tunnel**: 자체 통로 중심선에 다각형 단면을 스윕; 바닥·벽·천장을 별도 부재화; 연결: 2m 연결 그리드; 단면 연결 폭/높이 고정; 교차점 각 출구에 outward/up; 충돌: 바닥·벽·천장 분리 정적 충돌체; 통로 내부 비움; LOD0 목표 ≤1400 triangles.
- **surface**: 직접 정의한 높이 격자와 테두리 압출; 연결면 높이는 고정; 연결: 2m 그리드 가장자리 중심; 단차 목표 0m; 계단은 상하 착지점 명시; 충돌: 보행용 단순 면 또는 분할 convex; 계단은 승인된 램프 대체 가능; LOD0 목표 ≤500 triangles.
- **wall**: 자체 단면·절단면 좌표에서 석재 블록과 틈을 생성; 연결: 2m 단위 끝점; 모서리 방향 벡터 기록; 충돌: 관통 가능한 창/틈을 유지하는 분할 convex; LOD0 목표 ≤900 triangles.
- **ceiling**: 정의된 단면을 압출하고 외곽은 자체 seed로 변형; 연결: 높이 3m 연결면; 모듈 상단 체결점; 충돌: 천장 두께 영역만 분할 convex; LOD0 목표 ≤600 triangles.
- **hanging**: 자체 비대칭 링을 연결한 다각형 원뿔; 연결: 천장 접점 pivot; 축 방향 명시; 충돌: 선택적 단순 convex; 장식-only 기본 프로필 별도 표기; LOD0 목표 ≤500 triangles.
- **wall_prop**: 암벽 표면에 직접 설계한 다각 결정 배열; 연결: 벽 부착점과 법선; 충돌: 장식-only 기본; 필요 시 단순 convex 별도; LOD0 목표 ≤400 triangles.
- **door**: 자체 다각형 판재 압출과 기하학 홈; 연결: 힌지 pivot + 닫힘 방향; 문틀 접점; 충돌: 판 두께 box; 문틀과 독립; LOD0 목표 ≤350 triangles.
- **tent**: 자체 골조 선분과 텐트 천 다각면 조합; 개구부 유지; 연결: 바닥 중심 pivot; 입구 접근 기준점; 충돌: 골조·벽 분리; 실내/입구 통행 여부 명시; LOD0 목표 ≤1000 triangles.
- **prop**: 자체 좌표의 다각형 압출·회전체·링 또는 단순 부재 조합; 연결: 바닥 중심 pivot; 필요 부착점만 별도 기록; 충돌: box/capsule/convex 중 최저 복잡도; 복잡한 물체만 compound; LOD0 목표 ≤600 triangles.
- **crop**: 작물별 공통 성장 파라미터로 줄기·입체 잎·열매 생성; seed 고정; 연결: 같은 작물의 4단계 뿌리 pivot·방향·재배 셀 동일; 충돌: 장식-only 또는 상호작용용 단일 capsule; 단계별 일관성; LOD0 목표 ≤450 triangles.
- **tool**: 자체 도구 단면을 압출하고 손잡이 링을 연결; 연결: 손잡이 grip 점과 바닥/거치 기준점; 충돌: 단순 compound 2~3부재; LOD0 목표 ≤300 triangles.

- 열린 면은 의도와 기록이 있어야 함; NaN/퇴화삼각형/중복모델 차단. 세 테마는 geometry/socket 동일.
- LOD1 4방향 256px 실루엣 IoU>=0.95, LOD2>=0.88; 삼각형 절감률과 실제 엔진 전환도 함께 검토. 소형 모델 생략은 근거+사람 승인 필요.
- 혼합 모듈/코너/램프 연결 씬에서 틈·단차·중복충돌 검사; 0.4m 반경/1.8m 높이 테스트 캐릭터 통과. 이 치수는 제안이며 최종 게임 규격에 맞춰 확정.
- glTF Y-up와 제작 Z-up 변환 검사; socket·collider는 LOD 전환 시 보존.
- 84종 기존 승인 상태와 별개로 신규96종 모두 PENDING. 이미지·GLB·Blender·recipe·생성기·환경 버전 해시 연결.
- GLB 재질 목표1개, 기존 팔레트 공유. LOD0 삼각형 budget은 프로파일별 목표이며 측정값이 아님. 실제 모바일 성능 검사는 별도.

## 기존 팩과 구분할 부분

- CAVE는 내부 통행과 천장 결합이 있는 공간 모듈이다. 기존 야외 바위 변형으로 대체하지 않는다.
- RUIN은 벽체·층고·출입구 규격을 가진 실내/유적 구성이다. 기존 낮은 돌담과 착지용 길 계단에 단순 이름만 붙이지 않는다.
- CAMP는 기존 벤치·상자·표지판과 겹치지 않는 휴대 장비·취사·쉼터 중심이다.
- FARM은 작물 성장 단계와 재배 셀 일관성이 핵심이며 단순 색상 교체를 성장 단계로 세지 않는다.

검토해야 할 미결정 항목: 동굴과 유적의 그리드 전환 부재, 단계별 작물 상호작용 범위, 텐트 실내 통행 여부, 최종 LOD 생략 승인.
