import tempfile, shutil, unittest
from pathlib import Path
from package_audit import ROOT, seal, audit
class IntegrityTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.root=Path(self.temp.name)/'pack'
        shutil.copytree(ROOT,self.root,ignore=shutil.ignore_patterns('__pycache__','.godot'))
        seal(self.root)
    def tearDown(self):self.temp.cleanup()
    def test_clean(self):self.assertEqual(audit(self.root)['status'],'PASS')
    def test_tamper(self):
        with (self.root/'README.md').open('a') as f:f.write('tampered')
        self.assertEqual(audit(self.root)['status'],'FAIL')
    def test_missing_model(self):
        next((self.root/'godot_review/models').glob('*LOD0.glb')).unlink()
        self.assertEqual(audit(self.root)['status'],'FAIL')
    def test_extra_file(self):
        (self.root/'unexpected.txt').write_text('extra')
        self.assertEqual(audit(self.root)['status'],'FAIL')
if __name__=='__main__':unittest.main()
