"""Original ruin geometry. Coordinates are glTF Y-up metres; no asset imports."""
import math
from core import box, hull

STONE = ['#929A87', '#8E816C', '#69716B', '#A4A995']
DARK = '#424A4B'

def worn_block(name,center,size,color):
    points=[];bevel=.022
    for x in (-1,1):
        for y in (-1,1):
            for z in (-1,1):
                corner=[center[i]+sign*size[i]/2 for i,sign in enumerate((x,y,z))]
                for axis,sign in enumerate((x,y,z)):
                    p=corner.copy();p[axis]-=sign*bevel;points.append(p)
    return hull(name,points,color)


def socket(position, forward, width, height=3.0):
    return dict(position=position, forward=forward, up=[0, 1, 0],
                width=width, height=height)


def wall():
    parts = []
    # Offset courses are generated from independent full rectangular stones.
    for row in range(6):
        cuts = [-1, -.35, .35, 1] if row % 2 == 0 else [-1, -.68, 0, .68, 1]
        for k, (a, b) in enumerate(zip(cuts, cuts[1:])):
            # Small recessed joints; overall boundary dimensions remain exact.
            left = a if a == -1 else a + .008
            right = b if b == 1 else b - .008
            low = row * .5 + (.008 if row else 0)
            high = (row + 1) * .5 - (.008 if row < 5 else 0)
            parts.append(box(f'course_{row}_stone_{k}', [(left+right)/2, (low+high)/2, 0],
                             [right-left, high-low, .4], STONE[(row+k)%4]))
    return dict(asset_id='TW_RUIN_WALL_SOLID_A', components=parts,
                sockets=[socket([-1,0,0],[-1,0,0],.4),socket([1,0,0],[1,0,0],.4)],
                notes=['2m end-to-end modular wall. Recessed masonry joints are intentional.',
                       'Collision uses each masonry block; no animated or destructible behaviour.'])


def arch():
    parts=[]
    for side in [-1,1]:
        for row in range(5):
            lo=row*2.2/5
            hi=(row+1)*2.2/5
            parts.append(worn_block(f'jamb_{side}_{row}',[side*.875,(lo+hi)/2,0],
                             [.25,hi-lo,.6],STONE[(row+(side+1)//2)%4]))
    # Nine individually closed wedge stones. Inner opening width is exactly 1.5m.
    for i in range(9):
        a=i*math.pi/9
        b=(i+1)*math.pi/9
        ring=[(.75*math.cos(a),2.2+.65*math.sin(a)),
              (math.cos(a),2.2+.8*math.sin(a)),
              (math.cos(b),2.2+.8*math.sin(b)),
              (.75*math.cos(b),2.2+.65*math.sin(b))]
        points=[[x,y,z] for z in [-.3,.3] for x,y in ring]
        parts.append(hull(f'voussoir_{i}',points,STONE[i%4]))
    # Centre wedge owns the exact 3m crown; preserve exact target height.
    # Its polygon above already samples the crown at 80/100deg; add a small keystone cap.
    parts.append(box('keystone_cap',[0,2.985,0],[.22,.03,.6],STONE[3]))
    return dict(asset_id='TW_RUIN_ARCH_DOOR_A',components=parts,
                sockets=[socket([0,0,-.3],[0,0,-1],1.5,2.2),
                         socket([0,0,.3],[0,0,1],1.5,2.2)],
                notes=['Open passage: 1.5m wide by 2.2m rectangular clearance below arch.',
                       'Jambs and individual wedge convex colliders leave the entrance unobstructed.'])


def pillar():
    parts=[]
    levels=[(0,.16,.3,.3),(.16,.32,.3,.245),(.32,1.05,.235,.225),
            (1.05,1.12,.25,.25),(1.12,1.87,.225,.215),
            (1.87,1.94,.24,.24),(1.94,2.66,.215,.205),
            (2.66,2.82,.205,.3),(2.82,3,.3,.3)]
    for i,(lo,hi,r0,r1) in enumerate(levels):
        points=[[r*math.cos(k*math.tau/8),y,r*math.sin(k*math.tau/8)]
                for y,r in [(lo,r0),(hi,r1)] for k in range(8)]
        parts.append(hull(f'octagonal_drum_{i}',points,STONE[i%4]))
    return dict(asset_id='TW_RUIN_PILLAR_ROUND_A',components=parts,
                sockets=[dict(position=[0,0,0],forward=[0,-1,0],up=[0,0,1],width=.6,height=.6),
                         dict(position=[0,3,0],forward=[0,1,0],up=[0,0,1],width=.6,height=.6)],
                notes=['Eight-sided tapered shaft with raised collars; 0.6m footprint and 3m height.',
                       'Each drum is a separate closed convex collision part.'])


def stairs():
    parts=[]
    for i in range(6):
        h=(i+1)/6
        parts.append(box(f'step_{i}',[0,h/2,-1.25+i*.5],[2,h,.5],STONE[i%4]))
    return dict(asset_id='TW_RUIN_STAIRS_ASCENT_A',components=parts,
                sockets=[socket([0,0,-1.5],[0,0,-1],2,2.3),
                         socket([0,1,1.5],[0,0,1],2,2.3)],
                notes=['Six 0.166667m risers and 0.5m treads; rises toward +Z.',
                       'Upper socket is at Y=1m; lower socket is at Y=0m.',
                       'Stepped collider supplied. Engine-specific navigation/ramp collider requires separate approval.'])


def build():
    return [wall(),arch(),pillar(),stairs()]
