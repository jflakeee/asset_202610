"""Portable package integrity checks. No third-party dependencies."""
import hashlib, json, struct, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
MANIFEST='SHA256SUMS.json'
EXCLUDE={MANIFEST,'package_validation.json'}
def files(root):
    return sorted(p for p in root.rglob('*') if p.is_file() and not any(x in p.parts for x in ('.godot','__pycache__')) and p.name not in EXCLUDE and p.suffix!='.import')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def seal(root):
    data={p.relative_to(root).as_posix():digest(p) for p in files(root)}
    (root/MANIFEST).write_text(json.dumps(data,indent=2)+'\n')
    return len(data)
def audit(root):
    checks=[]
    def check(name,ok):checks.append({'name':name,'passed':bool(ok)})
    expected=json.loads((root/MANIFEST).read_text())
    actual={p.relative_to(root).as_posix():p for p in files(root)}
    check('file inventory matches',set(actual)==set(expected))
    for name,sha in expected.items():check('sha256 '+name,name in actual and digest(actual[name])==sha)
    base=root/'godot_review'
    catalog=json.loads((base/'catalog.json').read_text())['assets']
    ids=[a['asset_id'] for a in catalog]
    check('unique asset identifiers',len(ids)==len(set(ids)))
    for aid in ids:check('LOD0 exists '+aid,(base/'models'/f'{aid}_LOD0.glb').is_file())
    layouts=json.loads((base/'scenes/placements.json').read_text())
    for name,placements in layouts.items():
        check('assembly references '+name,all(p[0] in ids and len(p[1])==3 for p in placements))
    for p in sorted((base/'models').glob('*.glb')):
        raw=p.read_bytes()
        valid=len(raw)>=20
        if valid:
            magic,version,size=struct.unpack_from('<4sII',raw)
            valid=magic==b'glTF' and version==2 and size==len(raw)
        check('GLB header '+p.name,valid)
        if valid:
            size,kind=struct.unpack_from('<II',raw,12)
            check('GLB JSON chunk '+p.name,kind==0x4E4F534A and 20+size<=len(raw))
            doc=json.loads(raw[20:20+size])
            external=[v['uri'] for k in ('buffers','images') for v in doc.get(k,[]) if 'uri' in v and not v['uri'].startswith('data:')]
            check('self-contained GLB '+p.name,not external)
    return {'status':'PASS' if all(c['passed'] for c in checks) else 'FAIL','checks':checks,'scope':'File integrity, asset references, GLB headers and external dependencies; not visual or performance certification.'}
if __name__=='__main__':
    if '--seal' in sys.argv: print('Sealed',seal(ROOT),'files')
    result=audit(ROOT)
    (ROOT/'package_validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(result['status'],len(result['checks']),'checks')
    raise SystemExit(result['status']!='PASS')
