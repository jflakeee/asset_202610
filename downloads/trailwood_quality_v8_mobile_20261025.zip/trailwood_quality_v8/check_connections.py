"""Validate declared translation-only assembly socket connections; Python stdlib."""
import json, math
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def inspect(catalog, placements, links):
    assets = {a['asset_id']: a for a in catalog['assets']}
    results = []
    for link in links:
        ends = []
        for index, name in link['ends']:
            aid, offset = placements[link['scene']][index]
            socket = next(s for s in assets[aid]['sockets'] if s['name'] == name)
            ends.append((socket, [a+b for a,b in zip(socket['position'], offset)]))
        (a, pa), (b, pb) = ends
        gap = math.dist(pa, pb)
        def unit(v):
            length = math.sqrt(sum(x*x for x in v))
            if length == 0: raise ValueError('Zero socket direction')
            return [x/length for x in v]
        facing = sum(x*y for x,y in zip(unit(a['forward']), unit(b['forward'])))
        upright = sum(x*y for x,y in zip(unit(a['up']), unit(b['up'])))
        dimensions = max(abs(a[k]-b[k]) for k in ('width','height'))
        results.append({'scene':link['scene'], 'ends':link['ends'], 'gap_m':gap,
                        'forward_dot':facing, 'up_dot':upright, 'dimension_delta_m':dimensions,
                        'passed':gap<=.001 and facing<=-.9999 and upright>=.9999 and dimensions<=.001})
    return results

def load():
    base=ROOT/'godot_review'
    return (json.loads((base/'catalog.json').read_text()),
            json.loads((base/'scenes/placements.json').read_text()),
            json.loads((base/'scenes/connections.json').read_text()))

if __name__=='__main__':
    results=inspect(*load())
    report={'scope':'Declared translation-only socket joins; not geometry or physics certification',
            'status':'PASS' if results and all(r['passed'] for r in results) else 'FAIL', 'connections':results}
    (ROOT/'connection_validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(report['status'],len(results),'connections')
    raise SystemExit(0 if report['status']=='PASS' else 1)
