# Trailwood 품질 8차 — 모바일 크기 대응

2026-10-25. Godot 검토 UI의 반응형 폭, 스크롤, 최소 48px 조작 영역, 패널 숨기기, 시점 초기화를 추가했습니다. 엔진 검사 162개 통과. MOBILE_REVIEW.md에 검사 범위와 제한을 기록했습니다. 아래는 이전 변경 이력입니다.

# Trailwood 품질 7차 — 패키지 무결성

2026-10-25. package_audit.py와 SHA256SUMS.json을 추가했습니다. 실행 안내와 검증 범위는 PACKAGE_CHECK.md를 참고하세요. 아래는 이전 버전 변경 이력입니다.

# Trailwood 품질 6차 — 조합 규칙 검증

2026-10-25. ASSEMBLY_GUIDE.md, check_connections.py, test_connections.py 및 명시적 소켓 연결 데이터를 추가했습니다. 연결 2곳 검사와 회귀 테스트 6개 통과. 기존 v5 엔진 결과 138개는 재실행 없이 보존했습니다.

# Trailwood 품질 5차 — 조합 장면 충돌체 및 LOD

2026-10-24. 신규12종, LOD1 3개와 배치 예제3개를 유지하며 Godot4.5 검토 프로젝트를 추가했습니다.

- godot_review/project.godot: 엔진 검토 화면. 실행 안내는 godot_review/README.md.
- output/index.html: 정적 이미지 갤러리.
- output/lod.html: LOD 비교와 조합 장면.
- godot_review/engine_validation.json: 실제 headless 엔진 검사138개 통과.

개별 모델의 convex 충돌체, 거리 기반LOD 자동전환, 8/10m 전환 유지 구간을 구현했습니다.
12종 로딩·충돌부품 수, 출입구 캡슐 검사, 직선통로 sweep, 벽/바닥 차단,
검토 장면15개 선택과 실제카메라 거리LOD 갱신을 Godot4.5에서 실행했습니다.
배치 예제 3개는 개별 에셋 인스턴스로 구성하며 각 충돌체와 LOD를 연결했습니다.
동굴의 연결부 두 곳을 지나 왼쪽 출구로 나가는 캡슐 sweep을 검증했습니다.
캠프/유적에는 공통 바닥이나 플레이어 컨트롤러가 없으며 전체 이동은 검증하지 않았습니다.

GPU 화면이나 모바일 성능을 검증한 것은 아닙니다. 마우스·터치 실조작,
연속 이동 컨트롤러, 계단/경사/동굴 외 조합 통행, LOD 색상팝·미술검토는 남아 있습니다.
UV·판매용 이미지·상품 문서 최종화도 필요합니다. 현재 상태는 판매완료판이 아닙니다.

기존 메시 재생성 순서: python build.py, python check_clearance.py,
python verify_batches.py, python build_lod_review.py.
메시를 다시 생성하면 output/models와 catalog.json을 godot_review에 동기화한 뒤 재검사해야 합니다.

원래96종 중 구현된 고유모델은12종이며 나머지84종은 미구현입니다.
이전 외형 비교는 output/before_after.png입니다.
GitHub 쓰기 권한403 문제로 이번판은 사이트에 배포되지 않았습니다.
