"""Sample declared doorway planes against independent convex collision equations.

This geometric check does not replace engine capsule navigation testing.
"""
from pathlib import Path
import json
import numpy as np
from scipy.spatial import ConvexHull
import cave,ruin,camp

def main():
    results=[]
    for a in cave.build()+ruin.build()+camp.build():
        if not (a['asset_id'].startswith('TW_CAVE_') or a['asset_id'] in ('TW_RUIN_ARCH_DOOR_A','TW_CAMP_TENT_RIDGE_A')):continue
        solids=[ConvexHull(p['vertices']).equations for p in a['components'] if p.get('collider',True)]
        for index,s in enumerate(a['sockets']):
            s.setdefault('name',f'port_{index}')
            if not s.get('width') or not s.get('height'):continue
            pos=np.array(s['position']);forward=np.array(s['forward']);up=np.array(s['up']);right=np.cross(forward,up)
            points=np.array([pos-forward*depth+right*x+up*y for depth in (0,.03,.1) for x in np.linspace(-s['width']/2+.025,s['width']/2-.025,11) for y in np.linspace(.025,s['height']-.025,13)])
            blocked=[i for i,p in enumerate(points) if any(np.all(e[:,:3]@p+e[:,3]<-1e-7) for e in solids)]
            assert not blocked,(a['asset_id'],s['name'],len(blocked))
            results.append(dict(asset_id=a['asset_id'],socket=s['name'],samples=len(points),blocked=len(blocked),status='PASS'))
    out=Path(__file__).parent/'output/clearance.json';out.write_text(json.dumps(dict(scope='Static portal sample check, 25mm edge inset, depths 0/30/100mm. Not continuous capsule or engine runtime validation.',results=results),indent=2))
    print(f'{len(results)} portal planes passed')

if __name__=='__main__':main()
