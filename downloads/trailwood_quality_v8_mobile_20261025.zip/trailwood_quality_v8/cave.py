"""Original faceted cave modules. Coordinates are Y-up metres.

The wall/ceiling volumes are separate convex solids, never a convex hull
around the entire tunnel. The common walk surface is Y=0.
"""
from core import box, hull

STONE = '#69716B'
DARK = '#424A4B'
LIGHT = '#929A87'


def socket(name, p, f):
    return dict(name=name, position=p, forward=f, up=[0,1,0],
                width=1.8, height=2.3)


def rock_wall(name, cx, cz, sx, sz, shade=STONE):
    # Preserve all boundary planes through the entire height so joined
    # modules never develop a triangular opening above eye level.
    points=[]
    for y, inset in [(0,0),(2.3,0)]:
        for x,z in [(-1,-1),(1,-1),(1,1),(-1,1)]:
            points.append([cx+x*(sx/2-inset),y,cz+z*(sz/2-inset)])
    # Bulges occur only between end planes; portal surfaces stay unchanged.
    if sx < sz and abs(cx)>.9:
        side=1 if cx>0 else -1
        points.extend([[cx+side*(sx/2+.16),.55,cz-sz*.15],
                       [cx+side*(sx/2+.10),1.6,cz+sz*.17]])
    elif sz < sx and abs(cz)>.9:
        side=1 if cz>0 else -1
        points.extend([[cx-sx*.16,.7,cz+side*(sz/2+.14)],
                       [cx+sx*.18,1.7,cz+side*(sz/2+.1)]])
    return hull(name,points,shade)


def shell(w,d):
    return [box('walk_floor',[0,-.1,0],[w,.2,d],DARK),
            hull('faceted_ceiling',[[x,y,z] for z in [-d/2,d/2]
                  for x,y in [(-w/2,2.3),(w/2,2.3),(w/2,2.82),(.6,3),(-.5,3),(-w/2,2.82)]]+
                 [[-.2,3.16,0],[.45,3.08,.15]],STONE)]


def asset(suffix, parts, sockets, extra=''):
    return dict(asset_id='TW_CAVE_'+suffix,components=parts,sockets=sockets,
                notes=['Original coordinate construction; no external mesh inputs.',
                       'Walk surface Y=0; underside of floor Y=-0.2; 1.8m clear ports and 2.3m minimum headroom.',
                       'Each wall, floor and ceiling uses an independent convex collision solid.',
                       'Measured envelope in validation.json; outer rock bulges and roof crown exceed the original box. Portal planes and clearances retained.',
                       extra])


def build():
    result=[]
    # Portal: the apparent arch uses three angular crown solids above the
    # unobstructed rectangular passage. No mesh or collider seals the opening.
    parts=[box('walk_floor',[0,-.1,0],[3,.2,1],DARK),
           rock_wall('left_rock',-1.2,0,.6,1),
           rock_wall('right_rock',1.2,0,.6,1,LIGHT)]
    for i,(x0,x1,top0,top1) in enumerate([(-1.5,-.5,2.7,3),(-.5,.5,3,3),(.5,1.5,3,2.7)]):
        points=[[x,y,z] for z in [-.5,.5]
                for x,y in [(x0,2.3),(x1,2.3),(x1,top1),(x0,top0)]]
        parts.append(hull('angular_crown_'+str(i),points,[STONE,LIGHT,DARK][i]))
    result.append(asset('ENTRANCE_ARCH_A',parts,
        [socket('south',[0,0,-.5],[0,0,-1]),socket('north',[0,0,.5],[0,0,1])],
        'Angular outer arch with flat safe headroom; 3×3.2×1m measured envelope.'))

    parts=shell(3,2)+[rock_wall('west_wall',-1.2,0,.6,2),
                     rock_wall('east_wall',1.2,0,.6,2,LIGHT)]
    result.append(asset('TUNNEL_STRAIGHT_A',parts,
        [socket('south',[0,0,-1],[0,0,-1]),socket('north',[0,0,1],[0,0,1])]))

    parts=shell(3,3)+[rock_wall('east_outer_wall',1.2,0,.6,3),
                     rock_wall('north_outer_wall',0,1.2,3,.6,LIGHT),
                     rock_wall('southwest_inner_corner',-1.2,-1.2,.6,.6,DARK)]
    result.append(asset('TUNNEL_CURVE_L_A',parts,
        [socket('south',[0,0,-1.5],[0,0,-1]),socket('west',[-1.5,0,0],[-1,0,0])],
        'Left turn when entering the south port and heading north.'))

    parts=shell(5,3)+[rock_wall('north_back_wall',0,1.2,5,.6),
                     rock_wall('south_west_wall',-1.7,-1.2,1.6,.6,LIGHT),
                     rock_wall('south_east_wall',1.7,-1.2,1.6,.6,DARK)]
    result.append(asset('TUNNEL_T_A',parts,
        [socket('south',[0,0,-1.5],[0,0,-1]),socket('west',[-2.5,0,0],[-1,0,0]),
         socket('east',[2.5,0,0],[1,0,0])],
        '5m-wide junction follows proposal envelope. Socket placement is explicit rather than imposing an incompatible 2m grid.'))
    return result
