import copy, unittest
from check_connections import load, inspect

class ConnectionTests(unittest.TestCase):
    def setUp(self): self.c, self.p, self.l=load()
    def passes(self): return all(r['passed'] for r in inspect(self.c,self.p,self.l))
    def test_valid(self): self.assertTrue(self.passes())
    def test_gap(self):
        self.p['cave_connection'][1][1][0]+=.002
        self.assertFalse(self.passes())
    def test_reversed_facing(self):
        self.c['assets'][next(i for i,a in enumerate(self.c['assets']) if a['asset_id']=='TW_CAVE_ENTRANCE_ARCH_A')]['sockets'][1]['forward']=[0,0,-1]
        self.assertFalse(self.passes())
    def test_height_mismatch(self):
        next(a for a in self.c['assets'] if a['asset_id']=='TW_CAVE_ENTRANCE_ARCH_A')['sockets'][1]['height']+=.01
        self.assertFalse(self.passes())
    def test_inverted_up(self):
        next(a for a in self.c['assets'] if a['asset_id']=='TW_CAVE_ENTRANCE_ARCH_A')['sockets'][1]['up']=[0,-1,0]
        self.assertFalse(self.passes())
    def test_missing_socket(self):
        self.l[0]['ends'][0][1]='missing'
        with self.assertRaises(StopIteration): inspect(self.c,self.p,self.l)

if __name__=='__main__': unittest.main()
