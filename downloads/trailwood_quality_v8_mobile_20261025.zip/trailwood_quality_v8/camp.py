"""Original Y-up camp prototypes; all coordinates authored procedurally here."""
import math
from core import box, hull, beam

WOOD = '796045'
WOOD_LIGHT = 'A18762'
CANVAS = 'A3AE6D'
CLOTH = '657C3C'
ROPE = 'C8A875'
IRON = '424A4B'


def socket(name, position, forward=(0, 0, -1), width=0, height=0):
    return dict(name=name, position=list(position), forward=list(forward),
                up=[0, 1, 0], width=width, height=height)


def tent():
    c = []
    # Each roof panel is a solid narrow triangular-prism slab. No overall
    # tent convex hull: the entrance and occupied volume remain empty.
    for side in (-1, 1):
        # A sampled cloth surface sags between the ridge and ground rail.
        # Each cell is a thin closed solid; no hull spans the occupied space.
        profile=[(0,1.8),(.6,.79),(1.2,.025)]
        depths=[-1.5,-.5,.5,1.5]
        for j,((x0,y0),(x1,y1)) in enumerate(zip(profile,profile[1:])):
            for k,(z0,z1) in enumerate(zip(depths,depths[1:])):
                points=[]
                for x,y in [(x0,y0),(x1,y1)]:
                    for z in (z0,z1):
                        sag=.035*(1-abs(z)/1.5)*(1 if x<1 else 0)
                        points.extend([[side*x,y-sag,z],[side*x,y-sag+.018,z]])
                c.append(hull(f'cloth_{side}_{j}_{k}',points,CANVAS))
        for z in (-1.43, 1.43):
            c.append(beam('sloped_frame', [side*1.13, .04, z],
                          [0, 1.74, z], .025, WOOD, segments=6))
        c.append(beam('ground_rail', [side*1.16, .03, -1.43],
                      [side*1.16, .03, 1.43], .025, WOOD, segments=6))
    c.append(beam('ridge_pole', [0, 1.745, -1.45], [0, 1.745, 1.45],
                  .025, WOOD_LIGHT, segments=6))
    # Back panel closed; front completely open under the A-frame.
    c.append(hull('back_canvas', [[x,y,z] for z in (1.46,1.49)
                    for x,y in [(-1.16,.025),(1.16,.025),(0,1.75)]], CLOTH))
    c.append(box('groundsheet', [0, .0075, 0], [2.25,.015,2.88], CLOTH, collider=False))
    for side in (-1,1):
        for z in (-1.25,1.25):
            c.append(beam('guy_rope',[side*.85,.41,z],[side*1.48,.05,z],.008,ROPE,segments=5,collider=False))
            c.append(beam('stake',[side*1.48,0,z],[side*1.51,.16,z],.022,WOOD,segments=5))
    return dict(asset_id='TW_CAMP_TENT_RIDGE_A', components=c,
                sockets=[socket('entry', [0,0,-1.5], width=1.05,height=.9)],
                notes=['Original A-frame tent with two closed cloth slabs and an open front.',
                       'Entry clearance narrows with height: crouch shelter, not an upright doorway.',
                       'Groundsheet is decorative; split frame and cloth colliders preserve interior.'])


def bedroll():
    c = []
    c.append(box('lower_mat',[0,.025,0],[.8,.05,2],CLOTH,collider=False))
    # A bevelled quilt outline creates a distinct soft silhouette without
    # borrowing a source mesh. Pillow remains within the 0.12 m height target.
    outline=[(-.37,-.95),(.37,-.95),(.4,-.86),(.4,.65),(.33,.75),(-.33,.75),(-.4,.65),(-.4,-.86)]
    c.append(hull('quilt',[[x,.04,z] for x,z in outline]+[[x*.88,.115,z*.95] for x,z in outline]+[[0,.15,-.65],[0,.16,.35]], CANVAS,collider=False))
    c.append(hull('pillow',[[x,y,z] for x,y,z in [
        (-.32,.05,.7),(.32,.05,.7),(.32,.05,.96),(-.32,.05,.96),
        (-.27,.18,.74),(.27,.18,.74),(.27,.18,.92),(-.27,.18,.92)]],ROPE,collider=False))
    for z in (-.65,.45):
        c.append(hull('packing_strap',[[x,y+dy,z+dz] for x,y in [(-.4,.065),(-.32,.12),(0,.16),(.32,.12),(.4,.065)] for dy in (0,.009) for dz in (-.022,.022)],WOOD,collider=False))
    for x in (-.31,.31):
        c.append(box('stitched_side_seam',[x,.123,-.11],[.016,.008,1.45],CLOTH,collider=False))
    return dict(asset_id='TW_CAMP_BEDROLL_OPEN_A',components=c,
                sockets=[socket('sleep_origin',[0,.12,.8],forward=(0,0,1))],
                notes=['Original rounded quilt, pillow, and packing straps. Height target revised from 0.12m to 0.18m for readable volume.',
                       'Decorative ground prop; no blocking colliders.'])


def tripod():
    c=[]
    for i in range(3):
        a=math.pi/2+i*2*math.pi/3
        foot=[.48*math.cos(a),.024,.48*math.sin(a)]
        top=[-.05*math.cos(a),1.47,-.05*math.sin(a)]
        c.append(beam('tripod_leg_'+str(i),foot,top,.024,WOOD,segments=6))
    for y in (1.31,1.35,1.39):
        c.append(box('binding',[0,y,0],[.135,.022,.135],ROPE,collider=False))
    c.append(beam('hanger',[0,1.34,0],[0,.78,0],.012,IRON,segments=6,collider=False))
    c.append(beam('hook_bottom',[0,.78,0],[.065,.78,0],.012,IRON,segments=6,collider=False))
    c.append(beam('hook_tip',[.065,.78,0],[.065,.84,0],.012,IRON,segments=6,collider=False))
    return dict(asset_id='TW_CAMP_COOKING_TRIPOD_A',components=c,
                sockets=[socket('pot_hanger',[.045,.8,0],forward=(0,0,1))],
                notes=['Three independent wooden legs and a metal hanging hook.',
                       'Cookware is a separate future asset; hook is decorative.'])


def drying_rack():
    c=[]
    for x in (-.64,.64):
        for z in (-.35,.35):
            c.append(beam('trestle_leg',[x,.025,z],[x,1.56,-z*.1],.025,WOOD,segments=6))
        c.append(beam('side_brace',[x,.72,-.2],[x,.72,.2],.02,WOOD_LIGHT,segments=6))
    for y,z in [(1.55,0),(.85,-.19),(.85,.19)]:
        c.append(beam('cross_rail',[-.675,y,z],[.675,y,z],.025,WOOD_LIGHT,segments=6))
    for i,x in enumerate((-.42,-.14,.14,.42)):
        end=1.14+[.03,.11,0,.07][i]
        c.append(beam('hanging_string',[x,1.52,0],[x,end,0],.006,ROPE,segments=5,collider=False))
        for j in range(2+i%3):
            a=j*2*math.pi/3+i*.35
            dx,dz=.065*math.cos(a),.065*math.sin(a)
            points=[[x,end,0],[x+dx,end-.24,dz],[x+dx+.045,end-.16,dz],
                    [x+dx,end-.11,dz+.04],[x+dx-.035,end-.16,dz-.025]]
            c.append(hull('hanging_herb',points,CLOTH if j%2 else CANVAS,collider=False))
    return dict(asset_id='TW_CAMP_DRYING_RACK_A',components=c,
                sockets=[socket('hanging_rail',[0,1.55,0])],
                notes=['Original trestle rack with four hanging herb bundles.',
                       'Only structural timber has collision; strings and herbs are decorative.'])


def build():
    return [tent(),bedroll(),tripod(),drying_rack()]
