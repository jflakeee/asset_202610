"""Original LOD variants, silhouette checks and actual-mesh assembly examples."""
from pathlib import Path
from collections import Counter
import copy,json,math
import numpy as np
from PIL import Image,ImageDraw
from scipy.spatial import ConvexHull
from core import box,hull,beam,glb
import cave,ruin,camp
from build import render

ROOT=Path(__file__).parent;OUT=ROOT/'output'

def reduced(asset):
    a=copy.deepcopy(asset);aid=a['asset_id'];parts=a['components']
    if 'ARCH_DOOR' in aid:
        for i,p in enumerate(parts):
            if p['name'].startswith('jamb_'):
                v=np.array(p['vertices']);parts[i]=box(p['name'],(v.min(0)+v.max(0))/2,np.ptp(v,axis=0),p['color'])
    elif 'TENT_RIDGE' in aid:
        keep=[p for p in parts if not p['name'].startswith(('cloth_','guy_rope','binding'))]
        for side in (-1,1):
            for j in (0,1):
                group=[p for p in parts if p['name'].startswith(f'cloth_{side}_{j}_')]
                keep.append(hull(f'cloth_{side}_{j}',[v for p in group for v in p['vertices']],group[0]['color']))
        a['components']=keep
    elif 'DRYING_RACK' in aid:
        keep=[p for p in parts if p['name']!='hanging_herb']
        groups={}
        for p in parts:
            if p['name']=='hanging_herb':
                v=np.array(p['vertices']);x=v[v[:,1].argmax(),0];groups.setdefault(round(float(x),3),[]).append(p)
        for i,group in enumerate(groups.values()):keep.append(hull(f'herb_bundle_{i}',[v for p in group for v in p['vertices']],group[0]['color'],False))
        for i,p in enumerate(keep):
            if p['name'] in ('trestle_leg','side_brace','cross_rail','hanging_string'):
                v=np.array(p['vertices']);n=len(v)//2;a0=v[:n].mean(0);a1=v[n:].mean(0);radius=np.linalg.norm(v[:n]-a0,axis=1).max()
                keep[i]=beam(p['name'],a0,a1,radius,p['color'],segments=4,collider=p.get('collider',True))
        a['components']=keep
    elif 'PILLAR_ROUND' in aid:
        keep=[p for i,p in enumerate(parts) if i not in (2,4,6)]
        bottom=np.array(parts[2]['vertices']);top=np.array(parts[6]['vertices'])
        points=bottom[np.isclose(bottom[:,1],bottom[:,1].min())].tolist()+top[np.isclose(top[:,1],top[:,1].max())].tolist()
        keep.append(hull('shaft_envelope',points,parts[2]['color']))
        a['components']=keep
    a['notes']=['LOD1 static render mesh; original LOD0 collision remains authoritative.']
    return a

VIEWS=[('front',0,0),('back',180,0),('left',90,0),('right',270,0),('top',0,90),('quarter',45,25)]
def mask(a,az,el,lo,hi):
    az,el=np.deg2rad([az,el]);right=np.array([np.cos(az),0,-np.sin(az)]);up=np.array([-np.sin(el)*np.sin(az),np.cos(el),-np.sin(el)*np.cos(az)])
    basis=np.array([right,up]);center=(lo+hi)/2;scale=360/np.linalg.norm(hi-lo)
    im=Image.new('1',(400,400));draw=ImageDraw.Draw(im)
    for p in a['components']:
        v=(np.array(p['vertices'])-center)@basis.T*scale;v[:,1]*=-1;v+=200
        for f in p['faces']:draw.polygon([tuple(x) for x in v[f]],fill=1)
    return np.array(im)

def check(a):
    for p in a['components']:
        v=np.array(p['vertices']);f=np.array(p['faces']);t=v[f];assert np.isfinite(v).all()
        assert np.all(np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)>1e-9)
        e=Counter(tuple(sorted((int(x),int(y)))) for tri in f for x,y in zip(tri,np.roll(tri,-1)));assert all(n==2 for n in e.values())
        assert np.einsum('ij,ij->i',t[:,0],np.cross(t[:,1],t[:,2])).sum()>0

def main():
    assets=cave.build()+ruin.build()+camp.build();by={a['asset_id']:a for a in assets}
    suffixes=['TW_RUIN_ARCH_DOOR_A','TW_RUIN_PILLAR_ROUND_A','TW_CAMP_TENT_RIDGE_A'];reports=[]
    for folder in ['lod_previews','lod_sources','scenes']:(OUT/folder).mkdir(exist_ok=True)
    for aid in suffixes:
        a=by[aid];b=reduced(a);check(b);n0=sum(len(p['faces']) for p in a['components']);n1=sum(len(p['faces']) for p in b['components']);assert n1<n0*.8,(aid,n0,n1)
        v=np.array([v for p in a['components']+b['components'] for v in p['vertices']]);lo=v.min(0);hi=v.max(0);views=[]
        for name,az,el in VIEWS:
            m0=mask(a,az,el,lo,hi);m1=mask(b,az,el,lo,hi);iou=float((m0&m1).sum()/(m0|m1).sum());views.append(dict(view=name,iou=iou));assert iou>=.9,(aid,name,iou)
        (OUT/'models'/f'{aid}_LOD1.glb').write_bytes(glb(b));(OUT/'lod_sources'/f'{aid}_LOD1.json').write_text(json.dumps(b,indent=2));render(b,OUT/'lod_previews'/f'{aid}.png')
        reports.append(dict(asset_id=aid,lod0_triangles=n0,lod1_triangles=n1,reduction_percent=round((1-n1/n0)*100,1),views=views,status='STATIC_SILHOUETTE_PASS',runtime_transition='NOT_TESTED'))
    exceptions=[dict(asset_id=a['asset_id'],decision='LOD0_ONLY_REVIEW',reason='Low baseline geometry; additional LOD deferred pending scene profiling, not an approved permanent exception.') for a in assets if a['asset_id'] not in suffixes]
    (OUT/'lod_review.json').write_text(json.dumps(dict(lods=reports,exceptions=exceptions,rejected_candidates=[dict(asset_id='TW_CAMP_DRYING_RACK_A',view='top',iou=.8518266394372589,decision='NOT_EXPORTED',reason='Candidate fails .90 silhouette threshold; keep LOD0.')],method='400px binary silhouette IoU in six orthographic views, threshold .90. Does not measure shading, perspective animation or perceptual popping.'),indent=2))
    layouts={
      'cave_connection':[('TW_CAVE_ENTRANCE_ARCH_A',[0,0,0]),('TW_CAVE_TUNNEL_STRAIGHT_A',[0,0,1.5]),('TW_CAVE_TUNNEL_CURVE_L_A',[0,0,4])],
      'camp_setup':[('TW_CAMP_TENT_RIDGE_A',[-1.8,0,.5]),('TW_CAMP_BEDROLL_OPEN_A',[-1.8,.02,.6]),('TW_CAMP_COOKING_TRIPOD_A',[1,0,-1]),('TW_CAMP_DRYING_RACK_A',[1.5,0,1.5])],
      'ruin_entry':[('TW_RUIN_ARCH_DOOR_A',[0,0,0]),('TW_RUIN_WALL_SOLID_A',[-2,0,0]),('TW_RUIN_WALL_SOLID_A',[2,0,0]),('TW_RUIN_PILLAR_ROUND_A',[-1.4,0,-.8]),('TW_RUIN_PILLAR_ROUND_A',[1.4,0,-.8])]
    }
    for name,placements in layouts.items():
        parts=[]
        for aid,offset in placements:
            for p in by[aid]['components']:
                p=copy.deepcopy(p);p['vertices']=(np.array(p['vertices'])+offset).tolist();parts.append(p)
        scene=dict(asset_id=name,components=parts,sockets=[]);(OUT/'scenes'/f'{name}.glb').write_bytes(glb(scene));render(scene,OUT/'scenes'/f'{name}.png')
    (OUT/'scenes/placements.json').write_text(json.dumps(layouts,indent=2))
    print(json.dumps([{k:v for k,v in r.items() if k!='views'} for r in reports],indent=2))

if __name__=='__main__':main()
