"""Check exported material groups against every authored triangle."""
import json,struct
from pathlib import Path
from collections import Counter
import numpy as np
import cave,ruin,camp

root=Path(__file__).parent;rows=[]
for asset in cave.build()+ruin.build()+camp.build():
    aid=asset['asset_id'];b=(root/'output/models'/f'{aid}_LOD0.glb').read_bytes()
    size=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+size]);binary=b[28+size:]
    def read(index):
        a=d['accessors'][index];v=d['bufferViews'][a['bufferView']]
        return np.frombuffer(binary,dtype='<f4',count=a['count']*3,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,3)
    def key(t):return tuple(np.asarray(t,dtype='<f4').ravel().tolist())
    expected={}
    for p in asset['components']:
        color=p['color'].lstrip('#').upper();expected.setdefault(color,Counter()).update(key(t) for t in np.array(p['vertices'])[p['faces']])
    seen=set()
    for p in d['meshes'][0]['primitives']:
        color=d['materials'][p['material']]['name'];assert color not in seen;seen.add(color)
        pos=read(p['attributes']['POSITION']);normal=read(p['attributes']['NORMAL']);assert Counter(key(t) for t in pos.reshape(-1,3,3))==expected[color]
        assert np.allclose(np.linalg.norm(normal,axis=1),1,atol=1e-6)
    assert seen==set(expected)
    rows.append(dict(asset_id=aid,authored_parts=len(asset['components']),render_primitives=len(seen),triangle_color_preservation='PASS'))
(root/'output/batching_validation.json').write_text(json.dumps(rows,indent=2));print('12 color-batch preservation checks passed')
