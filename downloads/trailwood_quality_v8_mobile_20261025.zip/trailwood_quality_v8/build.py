"""Rebuild original prototypes, structural checks, previews and offline gallery."""
from pathlib import Path
from collections import Counter
import json, hashlib, html
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from core import glb
import cave,ruin,camp
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'output'

def render(asset,path):
    fig=plt.figure(figsize=(5,4),facecolor='#e9e5dc');ax=fig.add_subplot(111,projection='3d');ax.set_facecolor('#e9e5dc')
    allv=[]
    for part in asset['components']:
        v=np.asarray(part['vertices'])[:,[0,2,1]];f=np.asarray(part['faces']);allv.append(v)
        rgb=np.array([int(part['color'].lstrip('#')[i:i+2],16)/255 for i in (0,2,4)])
        t=v[f];n=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);n/=np.linalg.norm(n,axis=1)[:,None]
        light=np.array([-.4,-.5,.8]);light/=np.linalg.norm(light)
        shades=.58+.42*np.abs(n@light);colors=np.clip(rgb[None,:]*shades[:,None],0,1)
        ax.add_collection3d(Poly3DCollection(t,facecolors=colors,edgecolors='#433f3820',linewidths=.18))
    v=np.concatenate(allv);mid=(v.min(0)+v.max(0))/2;half=np.ptp(v,axis=0).max()*.57
    ax.set(xlim=(mid[0]-half,mid[0]+half),ylim=(mid[1]-half,mid[1]+half),zlim=(mid[2]-half,mid[2]+half));ax.set_box_aspect((1,1,1));ax.view_init(24,-58);ax.set_axis_off()
    fig.tight_layout(pad=0);fig.savefig(path,dpi=120,facecolor=fig.get_facecolor());plt.close(fig)

def main():
    assets=cave.build()+ruin.build()+camp.build()
    spec=json.loads((ROOT/'expansion_research/expansion96.json').read_text());lookup={r['asset_id']:r for r in spec['assets']}
    assert len(assets)==12 and len({a['asset_id'] for a in assets})==12
    for folder in ['models','previews','sources']:(OUT/folder).mkdir(parents=True,exist_ok=True)
    report=[];catalog=[]
    for a in assets:
        aid=a['asset_id'];assert aid in lookup;total=0;allv=[]
        for p in a['components']:
            v=np.asarray(p['vertices']);f=np.asarray(p['faces']);assert np.isfinite(v).all() and f.min()>=0 and f.max()<len(v)
            t=v[f];normal=np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]);assert np.all(np.linalg.norm(normal,axis=1)>1e-9),(aid,p['name'],'degenerate')
            edges=Counter(tuple(sorted((int(x),int(y)))) for tri in f for x,y in zip(tri,np.roll(tri,-1)));assert all(n==2 for n in edges.values()),(aid,p['name'],'open part')
            volume=np.einsum('ij,ij->i',t[:,0],np.cross(t[:,1],t[:,2])).sum()/6;assert volume>0,(aid,p['name'],'orientation')
            total+=len(f);allv.append(v)
        for index,s in enumerate(a.get('sockets',[])):
            s.setdefault('name',f'port_{index}')
            assert all(np.isfinite(s[k]).all() for k in ['position','forward','up'])
            assert np.isclose(np.linalg.norm(s['forward']),1) and np.isclose(np.linalg.norm(s['up']),1)
            assert abs(np.dot(s['forward'],s['up']))<1e-6
        v=np.concatenate(allv);budget=spec['profiles'][lookup[aid]['profile']]['lod0_triangle_budget']
        assert total<=budget,(aid,total,budget)
        raw=glb(a);assert raw==glb(a);(OUT/'models'/f'{aid}_LOD0.glb').write_bytes(raw)
        (OUT/'sources'/f'{aid}.json').write_text(json.dumps(a,ensure_ascii=False,indent=2))
        render(a,OUT/'previews'/f'{aid}.png')
        report.append(dict(asset_id=aid,triangles=total,budget=budget,components=len(a['components']),dimensions_xyz_m=np.ptp(v,axis=0).round(5).tolist(),bounds_min=v.min(0).round(5).tolist(),bounds_max=v.max(0).round(5).tolist(),sha256=hashlib.sha256(raw).hexdigest(),structural_status='PASS',art_approval='PENDING',runtime_collision='NOT_TESTED',lod1='NOT_IMPLEMENTED'))
        catalog.append(dict(asset_id=aid,name_ko=lookup[aid]['name_ko'],file=f'models/{aid}_LOD0.glb',preview=f'previews/{aid}.png',sockets=a.get('sockets',[]),collider=dict(type='compound_convex',coordinate_frame='Y-up meters',parts=[dict(name=p['name'],points=p['vertices']) for p in a['components'] if p.get('collider',True)]),notes=a.get('notes',[])))
    (OUT/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    (OUT/'catalog.json').write_text(json.dumps(dict(status='PROTOTYPE',assets=catalog,external_geometry_inputs=[],coordinate_frame='Y-up meters'),ensure_ascii=False,indent=2))
    from PIL import Image,ImageDraw
    sheet=Image.new('RGB',(1200,1020),'#e9e5dc');draw=ImageDraw.Draw(sheet)
    for i,c in enumerate(catalog):
        im=Image.open(OUT/c['preview']).convert('RGB');im.thumbnail((300,280));x=i%4*300;y=i//4*340;sheet.paste(im,(x,y));draw.text((x+8,y+290),c['asset_id'].replace('TW_',''),fill='#18231e')
    sheet.save(OUT/'contact_sheet.png')
    status=[dict(asset_id=r['asset_id'],status='PROTOTYPE_LOD0' if r['asset_id'] in {a['asset_id'] for a in assets} else 'NOT_IMPLEMENTED') for r in spec['assets']]
    (OUT/'implementation_status.json').write_text(json.dumps(status,indent=2))
    cards=''.join(f'<article><a href="{c["preview"]}"><img loading="lazy" src="{c["preview"]}" alt="{html.escape(c["name_ko"])}"></a><h2>{html.escape(c["name_ko"])}</h2><p>{c["asset_id"]}</p><a download href="{c["file"]}">GLB 다운로드</a></article>' for c in catalog)
    (OUT/'index.html').write_text('<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Trailwood 신규 12종 프로토타입</title><style>body{margin:0;background:#18231e;color:#eee;font:16px system-ui}header,main{max-width:1200px;margin:auto;padding:24px}h1{font-size:30px}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px}article{background:#29372f;border-radius:16px;overflow:hidden;padding-bottom:20px}img{width:100%;display:block}h2,p,article a:not(:first-child){margin:16px}h2{font-size:20px}p{font-size:11px;overflow-wrap:anywhere}a{color:#d8cb8f}</style><header><h1>Trailwood / Expansion 01</h1><p>자체 생성 프로토타입 12종 · 이미지 클릭으로 확대 · GLB 개별 다운로드</p><p>구조 검증 완료 / 아트·엔진 충돌·LOD 검토 미완료. 이미지는 CPU 메시 렌더이며 게임 엔진 화면이 아닙니다.</p></header><main>'+cards+'</main></html>')
    print(json.dumps(dict(assets=len(assets),triangles=sum(r['triangles'] for r in report),status='STRUCTURAL_PASS')))

if __name__=='__main__':main()
