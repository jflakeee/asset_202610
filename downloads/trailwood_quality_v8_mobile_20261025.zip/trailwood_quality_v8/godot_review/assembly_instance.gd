extends Node3D

const AssetInstance = preload("res://asset_instance.gd")
var instances: Array = []

func configure(placements: Array, entries: Array) -> void:
	var catalog: Dictionary = {}
	for entry in entries:
		catalog[entry.asset_id] = entry
	for placement in placements:
		var instance = AssetInstance.new()
		add_child(instance)
		instance.position = Vector3(placement[1][0], placement[1][1], placement[1][2])
		instance.configure(catalog[placement[0]])
		instances.append(instance)

func update_from_camera(camera: Camera3D) -> void:
	for instance in instances:
		instance.update_from_camera(camera)

func summary() -> String:
	var far_count = 0
	var shape_count = 0
	for instance in instances:
		far_count += instance.current_lod
		shape_count += instance.body.get_child_count()
	return "Assembly: %d assets | LOD1: %d | Collision parts: %d" % [instances.size(), far_count, shape_count]
