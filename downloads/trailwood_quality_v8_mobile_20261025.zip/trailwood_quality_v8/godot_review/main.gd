extends Node3D

const AssetInstance = preload("res://asset_instance.gd")
const AssemblyInstance = preload("res://assembly_instance.gd")
var panel: VBoxContainer
var scroll: ScrollContainer
var toggle: Button
var picker: OptionButton
var camera: Camera3D
var active: Node3D
var status: Label
var distance_slider: HSlider
var entries: Array
var yaw: float = 0.6
var elevation: float = 0.4

func _ready() -> void:
	entries = JSON.parse_string(FileAccess.get_file_as_string("res://catalog.json")).assets
	var light = DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-50,-30,0)
	light.light_energy = 1.8
	add_child(light)
	var world = WorldEnvironment.new()
	world.environment = Environment.new()
	world.environment.background_mode = Environment.BG_COLOR
	world.environment.background_color = Color(0.10,0.14,0.12)
	world.environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	world.environment.ambient_light_color = Color(0.8,0.85,0.8)
	world.environment.ambient_light_energy = 0.7
	add_child(world)
	camera = Camera3D.new()
	camera.current = true
	add_child(camera)
	var ui = CanvasLayer.new()
	add_child(ui)
	toggle = Button.new()
	toggle.text = "Hide controls"
	toggle.custom_minimum_size = Vector2(160,48)
	toggle.position = Vector2(12,12)
	toggle.pressed.connect(toggle_controls)
	ui.add_child(toggle)
	scroll = ScrollContainer.new()
	scroll.position = Vector2(12,68)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	ui.add_child(scroll)
	panel = VBoxContainer.new()
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(panel)
	var title = Label.new()
	title.text = "TRAILWOOD / ENGINE REVIEW"
	title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	panel.add_child(title)
	picker = OptionButton.new()
	picker.fit_to_longest_item = false
	picker.clip_text = true
	picker.custom_minimum_size.y = 48
	for entry in entries:
		picker.add_item(entry.asset_id.replace("TW_", "").replace("_", " "))
	for name in ["cave_connection","camp_setup","ruin_entry"]:
		picker.add_item("ASSEMBLY / " + name)
	picker.item_selected.connect(show_asset)
	panel.add_child(picker)
	distance_slider = HSlider.new()
	distance_slider.custom_minimum_size.y = 48
	distance_slider.min_value = 3
	distance_slider.max_value = 18
	distance_slider.step = 0.1
	distance_slider.value = 6
	panel.add_child(distance_slider)
	status = Label.new()
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	panel.add_child(status)
	var reset = Button.new()
	reset.text = "Reset view"
	reset.custom_minimum_size.y = 48
	reset.pressed.connect(reset_view)
	panel.add_child(reset)
	var hint = Label.new()
	hint.text = "Drag scene to orbit. Slider changes distance. LOD1 >10m / LOD0 <8m. Collision stays fixed."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	panel.add_child(hint)
	get_viewport().size_changed.connect(resize_controls)
	resize_controls()
	show_asset(0)

func resize_controls() -> void:
	layout_controls(get_viewport().get_visible_rect().size)

func layout_controls(view_size: Vector2) -> void:
	scroll.size = Vector2(minf(420, maxf(1, view_size.x-24)), maxf(48, view_size.y*0.45))
	picker.get_popup().max_size = Vector2i(int(scroll.size.x), int(view_size.y*0.6))

func toggle_controls() -> void:
	scroll.visible = not scroll.visible
	toggle.text = "Hide controls" if scroll.visible else "Show controls"

func reset_view() -> void:
	yaw = 0.6
	elevation = 0.4
	distance_slider.value = 6

func show_asset(index: int) -> void:
	if active != null:
		remove_child(active)
		active.queue_free()
	if index < entries.size():
		active = AssetInstance.new()
		add_child(active)
		active.configure(entries[index])
	else:
		var names = ["cave_connection","camp_setup","ruin_entry"]
		active = AssemblyInstance.new()
		add_child(active)
		var layouts = JSON.parse_string(FileAccess.get_file_as_string("res://scenes/placements.json"))
		active.configure(layouts[names[index-entries.size()]], entries)

func _process(_delta: float) -> void:
	if camera == null or active == null: return
	var target = Vector3(0,1.2,0)
	var distance = distance_slider.value
	camera.position = target + Vector3(sin(yaw)*cos(elevation),sin(elevation),cos(yaw)*cos(elevation))*distance
	camera.look_at(target)
	if active.has_method("update_from_camera"):
		active.update_from_camera(camera)
		if active.has_method("summary"):
			status.text = active.summary()
		else:
			status.text = "Distance %.1fm | LOD %d | Collision parts %d" % [camera.position.length(),active.current_lod,active.body.get_child_count()]
	else:
		status.text = "Static assembly preview"

func _unhandled_input(event: InputEvent) -> void:
	var motion = Vector2.ZERO
	if event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		motion = event.relative
	elif event is InputEventScreenDrag:
		motion = event.relative
	yaw -= motion.x*.006
	elevation = clampf(elevation+motion.y*.005,-0.1,1.3)
