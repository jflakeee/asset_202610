extends SceneTree

const AssetInstance = preload("res://asset_instance.gd")
var checks: Array = []
var failures: Array = []

func record(name: String, passed: bool) -> void:
	checks.append({"name":name,"passed":passed})
	if not passed: failures.append(name)

func _initialize() -> void:
	call_deferred("run")

func run() -> void:
	var world = Node3D.new()
	root.add_child(world)
	var entries = JSON.parse_string(FileAccess.get_file_as_string("res://catalog.json")).assets
	var objects: Dictionary = {}
	for i in range(entries.size()):
		var entry = entries[i]
		var a = AssetInstance.new()
		world.add_child(a)
		a.position.x = i*10
		a.configure(entry)
		objects[entry.asset_id] = a
		record(entry.asset_id+" loaded",a.lod0 != null)
		record(entry.asset_id+" collider count",a.body.get_child_count()==entry.collider.parts.size())
		var body_id = a.body.get_instance_id()
		if a.lod1 != null:
			a.set_distance(11);record(entry.asset_id+" far switches",a.current_lod==1 and a.lod1.visible and not a.lod0.visible)
			a.set_distance(9);record(entry.asset_id+" hysteresis holds far",a.current_lod==1)
			a.set_distance(7);record(entry.asset_id+" near switches",a.current_lod==0 and a.lod0.visible and not a.lod1.visible)
			a.set_distance(9);record(entry.asset_id+" hysteresis holds near",a.current_lod==0)
			record(entry.asset_id+" collision identity stable",a.body.get_instance_id()==body_id)
	await physics_frame
	await physics_frame
	var space = world.get_world_3d().direct_space_state
	for entry in entries:
		var aid: String = entry.asset_id
		if not (aid.begins_with("TW_CAVE_") or aid=="TW_RUIN_ARCH_DOOR_A" or aid=="TW_CAMP_TENT_RIDGE_A"): continue
		var a = objects[aid]
		var crouch = aid=="TW_CAMP_TENT_RIDGE_A"
		for socket in entry.sockets:
			var pos = Vector3(socket.position[0],socket.position[1],socket.position[2]) + a.position
			var direction = Vector3(socket.forward[0],socket.forward[1],socket.forward[2])
			var capsule = CapsuleShape3D.new()
			capsule.radius = 0.20 if crouch else 0.30
			capsule.height = 0.80 if crouch else 1.80
			for depth in [-0.15,0.0,0.15,0.3]:
				var query = PhysicsShapeQueryParameters3D.new()
				query.shape = capsule
				query.transform.origin = pos-direction*depth+Vector3(0,capsule.height/2+0.03,0)
				query.margin = 0.001
				record(aid+" capsule portal "+str(socket.get("name","port"))+" "+str(depth),space.intersect_shape(query).is_empty())
	var straight = objects["TW_CAVE_TUNNEL_STRAIGHT_A"]
	var ray = PhysicsRayQueryParameters3D.create(straight.position+Vector3(0,1,0),straight.position+Vector3(2,1,0))
	record("cave wall blocks ray",not space.intersect_ray(ray).is_empty())
	ray = PhysicsRayQueryParameters3D.create(straight.position+Vector3(0,1,0),straight.position+Vector3(0,-1,0))
	record("cave floor blocks ray",not space.intersect_ray(ray).is_empty())
	var walker = CharacterBody3D.new()
	var walker_shape = CollisionShape3D.new()
	var capsule = CapsuleShape3D.new()
	capsule.radius = 0.3
	capsule.height = 1.8
	walker_shape.shape = capsule
	walker.add_child(walker_shape)
	world.add_child(walker)
	walker.position = straight.position+Vector3(0,0.93,-1.6)
	await physics_frame
	var blocked = false
	for step in range(32):
		if walker.move_and_collide(Vector3(0,0,0.1)) != null: blocked = true
	record("capsule sweeps through straight tunnel",not blocked and walker.position.z>1.5)
	walker.position = straight.position+Vector3(0,0.93,0)
	record("capsule sweep blocked by wall",walker.move_and_collide(Vector3(2,0,0)) != null)
	walker.position = straight.position+Vector3(0,0.93,0)
	record("capsule sweep blocked by floor",walker.move_and_collide(Vector3(0,-0.5,0)) != null)
	var review = (load("res://main.tscn") as PackedScene).instantiate()
	root.add_child(review)
	await process_frame
	for i in range(entries.size()+3):
		review.show_asset(i)
		record("review selection "+str(i),review.active != null)
	for i in range(entries.size()):
		if entries[i].asset_id == "TW_RUIN_ARCH_DOOR_A": review.show_asset(i)
	review.distance_slider.value = 14
	await process_frame
	await process_frame
	record("camera distance drives far LOD",review.active.current_lod==1)
	review.distance_slider.value = 4
	await process_frame
	await process_frame
	record("camera distance drives near LOD",review.active.current_lod==0)
	for screen_size in [Vector2(320,568),Vector2(375,667),Vector2(390,844),Vector2(568,320),Vector2(844,390),Vector2(768,1024),Vector2(1100,720)]:
		review.layout_controls(screen_size)
		await process_frame
		await process_frame
		record("panel fits "+str(screen_size), review.scroll.position.x+review.scroll.size.x<=screen_size.x and review.scroll.position.y+review.scroll.size.y<=screen_size.y)
		record("picker fits "+str(screen_size), review.picker.size.x<=review.scroll.size.x and review.picker.size.y>=48)
		record("slider touch height "+str(screen_size), review.distance_slider.size.y>=48)
	review.toggle_controls()
	record("controls hide",not review.scroll.visible)
	review.toggle_controls()
	record("controls restore",review.scroll.visible)
	review.yaw=2.0
	review.elevation=1.0
	review.distance_slider.value=15
	review.reset_view()
	record("reset camera controls",is_equal_approx(review.yaw,0.6) and is_equal_approx(review.elevation,0.4) and review.distance_slider.value==6)
	# Remove earlier fixtures so assembly queries run in isolation.
	world.queue_free()
	review.queue_free()
	await physics_frame
	await physics_frame
	var layouts = JSON.parse_string(FileAccess.get_file_as_string("res://scenes/placements.json"))
	for layout_name in ["cave_connection", "camp_setup", "ruin_entry"]:
		var assembly = preload("res://assembly_instance.gd").new()
		root.add_child(assembly)
		assembly.configure(layouts[layout_name], entries)
		record(layout_name+" instance count", assembly.instances.size()==layouts[layout_name].size())
		var cam = Camera3D.new()
		root.add_child(cam)
		cam.position = Vector3(0, 2, 30)
		assembly.update_from_camera(cam)
		for a in assembly.instances:
			record(layout_name+" "+a.asset_id+" far LOD", a.current_lod==(1 if a.lod1 != null else 0))
			var original_id = a.body.get_instance_id()
			cam.position = a.global_position+Vector3(0, 2, 3)
			a.update_from_camera(cam)
			record(layout_name+" "+a.asset_id+" near stable collision", a.current_lod==0 and a.body.get_instance_id()==original_id)
		await physics_frame
		await physics_frame
		if layout_name=="cave_connection":
			var mover = CharacterBody3D.new()
			var cs = CollisionShape3D.new()
			cs.shape = capsule
			mover.add_child(cs)
			root.add_child(mover)
			mover.position = Vector3(0,0.93,-0.8)
			await physics_frame
			var obstructed = false
			for step in range(48):
				if mover.move_and_collide(Vector3(0,0,0.1)) != null: obstructed = true
			record("assembly cave crosses both seams", not obstructed and mover.position.z>3.99)
			obstructed = false
			for step in range(18):
				if mover.move_and_collide(Vector3(-0.1,0,0)) != null: obstructed = true
			record("assembly cave turns and exits west", not obstructed and mover.position.x < -1.79)
			mover.queue_free()
		assembly.queue_free()
		cam.queue_free()
		await physics_frame
		await physics_frame
	var report = {"engine":Engine.get_version_info().string,"checks":checks,"failures":failures,"status":"PASS" if failures.is_empty() else "FAIL","scope":"Headless import, UI scene selection, camera-driven LOD, GodotPhysics3D capsule/ray queries and straight tunnel and assembled cave seam/corner sweeps; per-instance assembly LOD. No GPU, full locomotion controller or performance certification."}
	var file = FileAccess.open("res://engine_validation.json",FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"  "))
	file.close()
	print("ENGINE_REVIEW ",report.status," checks=",checks.size()," failures=",failures)
	quit(0 if failures.is_empty() else 1)
