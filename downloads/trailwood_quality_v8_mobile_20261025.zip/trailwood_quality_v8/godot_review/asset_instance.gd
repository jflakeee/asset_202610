extends Node3D

var lod0: Node3D
var lod1: Node3D
var body: StaticBody3D
var current_lod: int = 0
var asset_id: String
var switch_far: float = 10.0
var switch_near: float = 8.0

func configure(entry: Dictionary) -> void:
	asset_id = entry.asset_id
	var scene0 = load("res://models/" + asset_id + "_LOD0.glb") as PackedScene
	assert(scene0 != null, "Missing LOD0 " + asset_id)
	lod0 = scene0.instantiate()
	add_child(lod0)
	var lod1_path = "res://models/" + asset_id + "_LOD1.glb"
	if ResourceLoader.exists(lod1_path):
		lod1 = (load(lod1_path) as PackedScene).instantiate()
		add_child(lod1)
		lod1.visible = false
	body = StaticBody3D.new()
	body.name = "FixedLOD0Collision"
	add_child(body)
	for part in entry.collider.parts:
		var shape = ConvexPolygonShape3D.new()
		var points = PackedVector3Array()
		for p in part.points:
			points.append(Vector3(p[0],p[1],p[2]))
		shape.points = points
		var collision = CollisionShape3D.new()
		collision.shape = shape
		body.add_child(collision)
	set_distance(0.0)

func set_distance(distance: float) -> void:
	if lod1 == null:
		current_lod = 0
		return
	if current_lod == 0 and distance > switch_far:
		current_lod = 1
	elif current_lod == 1 and distance < switch_near:
		current_lod = 0
	lod0.visible = current_lod == 0
	lod1.visible = current_lod == 1

func update_from_camera(camera: Camera3D) -> void:
	set_distance(camera.global_position.distance_to(global_position))
