# Specifications and measured limits

- Unique models: 84; GLB exports: 252; thumbnails: 84.
- Metre units, Y-up GLB geometry, source Z-up collider descriptors.
- A/B variants have separate geometry. Palette themes do not increase the unique model count.
- This layout contains LOD0 only. No unsupported LOD-completeness or mobile-performance claim is made.
- Tested engineering environment: Godot4.7.2 Linux headless. GPU screenshots, physical Android/iOS, art approval and final terms are pending.
- Orthographic top-down examples should keep LOD0. Perspective initial distances: natural12/28m, boundary18/40m; grass cull25m. These are design starting values, not device recommendations.
- Gates in examples are static positions. Damaged fence collision can use a simplified intact proxy and needs review.
- Customer layout excludes generators, recipes, third-party research, credentials, caches and absolute machine paths.
