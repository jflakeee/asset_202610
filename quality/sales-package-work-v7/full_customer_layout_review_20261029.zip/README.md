# Trailwood full - INTERNAL REVIEW

84 unique LOD0 models; 3 palette theme(s); 252 GLB files.
This is a customer-layout preview, not a sales release or public free trial.
All models and thumbnails have pending art approval.

Start with docs/import-guide.md. See asset_manifest.json for exact IDs and contents.
This layout deliberately contains LOD0 only; the91 reduced Moss candidates and77 omission reviews remain separate engineering work. It does not claim the complete planned LOD deliverable.

Full layout includes84 thumbnails,6 contact sheets,6 static assembly descriptions/previews and an editable Blender source. Trial contains exactly8 Moss models and8 thumbnails, without the full Blender source or full examples.

LICENSE.txt is a pending-terms notice, not a grant of customer distribution rights.
