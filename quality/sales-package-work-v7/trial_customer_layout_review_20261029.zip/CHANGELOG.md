# Internal layout preview 2026-10-29

First explicit full/trial allowlists; JSON-derived CSV; verified editable-source paths; no sales approval.
