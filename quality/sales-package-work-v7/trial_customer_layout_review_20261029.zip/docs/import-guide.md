# Import guide

1. Unzip to a new directory. Check the file hashes in release_manifest.json before use.
2. Import models/glb/lod0/moss/<asset_id>_LOD0.glb into the engine at scale1.0. Coordinates are Y-up; units are metres. Each file embeds its palette.
3. The full layout also has dry and dusk folders. They recolor the same geometry, not additional model designs.
4. Godot4.7.2 Linux headless import is engineering evidence. Native Unity/URP support, GPU appearance and Android/iOS performance are not established.
5. In Godot's Advanced Import Settings disable Generate LODs before reimporting manually authored LODs. Automatic import collision must remain off if descriptors are used to construct collision.
6. Collision descriptors in asset_manifest.json are source Z-up: map(x,y,z) to(x,z,-y) exactly once. Grass/bush entries with null descriptors are nonblocking. Descriptors are separate data, not portable glTF physics.
7. The full Blender source is an editable imported mesh/UV/material/socket document, not a parametric generator. Its Moss image is packed; image paths are relative.
8. Static example JSONs describe assembly and are not ready-to-play scenes. No dynamic gate controller is included.

For material sharing, first confirm embedded materials render correctly, then replace matching materials with one shared palette material in your engine. Nearest sampling and disabled repeat avoid palette-slot bleed. A material per model does not imply one draw call for the scene.
