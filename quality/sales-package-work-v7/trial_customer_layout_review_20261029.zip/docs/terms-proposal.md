# Business terms proposal - not final contract language

Proposed use: commercial and noncommercial games, videos and images; modification inside the buyer's project.
Proposed restriction: resale or redistribution of original or modified models as downloadable asset packs or libraries.
Proposed team access: one purchasing organization and its project contributors; contractor access ends with the work.
Ownership is not exclusive. Trial terms must be separately stated; free pricing does not imply CC0.
Initial support scope: missing download files and import problems in the stated tested engine version. No response time, lifetime support or unlimited updates are promised.
Final platform terms, customer license, pricing and support commitments require signoff before release.
